DROP VIEW IF EXISTS posts_and_boosts
--;;
DROP VIEW IF EXISTS posts_with_meta
