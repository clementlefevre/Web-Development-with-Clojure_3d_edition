# Changes

## Base - `guestbook-base/`

Created project from:
`lein new luminus guestbook --template-version 3.91 -- +h2 +http-kit`

Some small changes, but more or less brand new luminus.
`.gitignore` updated to include generated files from later branches and other environment specific files, but include config files for purposes of including in the book.