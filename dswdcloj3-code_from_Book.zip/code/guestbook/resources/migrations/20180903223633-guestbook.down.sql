DROP TABLE guestbook;
