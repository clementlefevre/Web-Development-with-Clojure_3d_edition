ALTER TABLE users
  DROP COLUMN profile;