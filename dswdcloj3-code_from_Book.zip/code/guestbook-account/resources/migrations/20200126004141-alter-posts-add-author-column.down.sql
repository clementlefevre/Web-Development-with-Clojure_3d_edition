ALTER TABLE posts
  DROP COLUMN author;
