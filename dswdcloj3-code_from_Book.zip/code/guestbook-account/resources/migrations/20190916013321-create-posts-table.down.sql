DROP TABLE posts;
